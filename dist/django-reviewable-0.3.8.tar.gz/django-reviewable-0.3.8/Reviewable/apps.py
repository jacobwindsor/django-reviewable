from django.apps import AppConfig


class ReviewableConfig(AppConfig):
    name = 'Reviewable'
